const jwt = require('jsonwebtoken');
const Participant = require('../models/User');

exports.proteger = async (req, res, next) => {
  let token;

  if (
    req.headers.authorization &&
    req.headers.authorization.startsWith('Bearer')
  ) {
    try {
      token = req.headers.authorization.split(' ')[1];
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      req.participant = await Participant.findById(decoded.id).select('-motDePasse');
      next();
    } catch (error) {
      res.status(401).json({ message: 'Accès non autorisé, token invalide' });
    }
  }

  if (!token) {
    res.status(401).json({ message: 'Accès non autorisé, aucun token' });
  }
};
