const Participant = require('../models/Participant');

// Mettre à jour un participant
const updateParticipant = async (req, res) => {
  const { id } = req.params;
  const { nom, email, typeBillet, statut } = req.body;

  try {
    const participant = await Participant.findById(id);

    if (!participant) {
      return res.status(404).json({ message: 'Participant non trouvé' });
    }

    participant.nom = nom || participant.nom;
    participant.email = email || participant.email;
    participant.typeBillet = typeBillet || participant.typeBillet;
    participant.statut = statut !== undefined ? statut : participant.statut;

    const updatedParticipant = await participant.save();
    res.json(updatedParticipant);
  } catch (error) {
    res.status(500).json({ message: 'Erreur du serveur' });
  }
};

// Supprimer un participant
const deleteParticipant = async (req, res) => {
  const { id } = req.params;

  try {
    const participant = await Participant.findById(id);

    if (!participant) {
      return res.status(404).json({ message: 'Participant non trouvé' });
    }

    await participant.remove();
    res.json({ message: 'Participant supprimé' });
  } catch (error) {
    res.status(500).json({ message: 'Erreur du serveur' });
  }
};

module.exports = { updateParticipant, deleteParticipant };
