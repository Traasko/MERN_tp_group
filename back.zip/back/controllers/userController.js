const User = require('../models/User');
const jwt = require('jsonwebtoken');

// Générer un token JWT
const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: '30d' });
};

// Contrôleur pour l'inscription
const registerUser = async (req, res) => {
  const { nom, email, motDePasse } = req.body;

  try {
    // Vérifier si l'utilisateur existe déjà
    const userExists = await User.findOne({ email });

    if (userExists) {
      return res.status(400).json({ message: 'Utilisateur déjà inscrit' });
    }

    // Créer un nouvel utilisateur
    const user = await User.create({
      nom,
      email,
      motDePasse,
    });

    if (user) {
      res.status(201).json({
        _id: user._id,
        nom: user.nom,
        email: user.email,
        token: generateToken(user._id),
      });
    } else {
      res.status(400).json({ message: 'Données utilisateur invalides' });
    }
  } catch (error) {
    res.status(500).json({ message: 'Erreur du serveur' });
  }
};

// Contrôleur pour la connexion
const loginUser = async (req, res) => {
  const { email, motDePasse } = req.body;

  try {
    // Trouver l'utilisateur par email
    const user = await User.findOne({ email });

    if (user && (await user.matchPassword(motDePasse))) {
      res.json({
        _id: user._id,
        nom: user.nom,
        email: user.email,
        token: generateToken(user._id),
      });
    } else {
      res.status(401).json({ message: 'Identifiants invalides' });
    }
  } catch (error) {
    res.status(500).json({ message: 'Erreur du serveur' });
  }
};

module.exports = { registerUser, loginUser };
